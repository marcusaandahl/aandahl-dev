create view pg_stat_database_conflicts
            (datid, datname, confl_tablespace, confl_lock, confl_snapshot, confl_bufferpin, confl_deadlock) as
SELECT d.oid                                           AS datid,
       d.datname,
       pg_stat_get_db_conflict_tablespace(d.oid)       AS confl_tablespace,
       pg_stat_get_db_conflict_lock(d.oid)             AS confl_lock,
       pg_stat_get_db_conflict_snapshot(d.oid)         AS confl_snapshot,
       pg_stat_get_db_conflict_bufferpin(d.oid)        AS confl_bufferpin,
       pg_stat_get_db_conflict_startup_deadlock(d.oid) AS confl_deadlock
FROM pg_database d;

alter table pg_stat_database_conflicts
    owner to marcusaandahl;

grant select on pg_stat_database_conflicts to public;

